<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="stylesheet" href="css/edit.css">
</head>
<body>
    <div class="con1">
        <h1>Edit profile</h1>
        <hr>
        <h2>Mobile Number</h2><br>
         <a href="change_mobile.php"><button>Change</button></a>
        <br>
        <h2>Password</h2>
        <a href="change_password.php"><button>Change</button></a>
    
    </div>
</body>
</html>