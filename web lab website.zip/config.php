<?php
$servername="localhost";
$username="root";
$password="";
$database="painting_website";

$con=mysqli_connect($servername,$username,$password,$database);
?>